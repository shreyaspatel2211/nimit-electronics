<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="page-content browse container-fluid">
    <?php echo $__env->make('voyager::alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="row mb-3">
        <div class="col-md-6">
            <input type="text" id="search" class="form-control" placeholder="Search products..." value="<?php echo e(request()->get('search')); ?>">
        </div>
        <div class="col-md-3">
            <select id="items-per-page" class="form-control">
                <option value="10" <?php echo e(request()->get('per_page') == 10 ? 'selected' : ''); ?>>10</option>
                <option value="25" <?php echo e(request()->get('per_page') == 25 ? 'selected' : ''); ?>>25</option>
                <option value="50" <?php echo e(request()->get('per_page') == 50 ? 'selected' : ''); ?>>50</option>
                <option value="100" <?php echo e(request()->get('per_page') == 100 ? 'selected' : ''); ?>>100</option>
                <option value="500" <?php echo e(request()->get('per_page') == 500 ? 'selected' : ''); ?>>500</option>
                <option value="<?php echo e($totalProducts); ?>" <?php echo e(request()->get('per_page') == 'all' ? 'selected' : ''); ?>>All</option>
            </select>
        </div>
        <div class="col-md-3 text-right">
            <a href="<?php echo e(route('voyager.products.create')); ?>" class="btn btn-success">Add Product</a>
        </div>
    </div>

    <div class="row" id="product-list">
        <?php $__currentLoopData = $dataTypeContent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-3">
            <div class="card product-card">
                <?php
                $images = json_decode($product->images, true);
                ?>

                <div class="d-flex justify-content-center align-items-center">
                    <?php if(is_array($images) && count($images) > 0): ?>
                    <img src="<?php echo e(Storage::url($images[0])); ?>" class="card-img-top" alt="<?php echo e($product->name); ?>">
                    <?php endif; ?>
                </div>

                <div class="card-body">
                    <h3 class="card-title"><?php echo e($product->name); ?></h3>
                    <p><strong>Code</strong> : <?php echo e($product->code); ?></p>
                    <p><strong>Model</strong> : <?php echo e($product->model); ?></p>
                    <p><strong>Price</strong> : <?php echo e($product->price); ?></p>
                    <p><strong>Company</strong> : <?php echo e($product->company->name); ?></p>
                    <p><strong>RAM</strong> : <?php echo e($product->ram_memory); ?></p>
                    <p><strong>OS</strong> : <?php echo e($product->operating_system); ?></p>
                    <p><strong>Colour</strong> : <?php echo e($product->colour); ?></p>
                    <p><strong>Storage</strong> : <?php echo e($product->storage); ?></p>
                    <p><strong>Weight</strong> : <?php echo e($product->weight); ?></p>
                    <p><strong>Category</strong> : <?php echo e($product->category->name); ?></p>
                    <p><strong>Dimension</strong> : <?php echo e($product->product_dimensions); ?></p>
                    <p class="card-text"><strong>Description</strong><?php echo e(Str::limit(strip_tags($product->description), 100)); ?></p>

                    <?php if(count($product->offers) > 0): ?>
                    <p><strong>Offers</strong>
                    <ul>
                        <?php $__currentLoopData = $product->offers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $offer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a href="#" data-toggle="modal" data-target="#offerModal" data-title="<?php echo e($offer->title); ?>" data-price="<?php echo e($product->price); ?>" data-discount="<?php echo e($offer->discount); ?>" data-type="<?php echo e($offer->discount_type); ?>"><?php echo e($offer->title); ?></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    </p>
                    <?php endif; ?>


                    <a href="<?php echo e(route('voyager.products.show', $product->id)); ?>" class="btn btn-primary">View</a>
                    <a href="<?php echo e(route('voyager.products.edit', $product->id)); ?>" class="btn btn-warning">Edit</a>
                    <form action="<?php echo e(route('voyager.products.destroy', $product->id)); ?>" method="POST" style="display:inline">
                        <?php echo e(csrf_field()); ?>

                        <?php echo e(method_field('DELETE')); ?>

                        <button type="submit" class="btn btn-danger">Delete</button>
                    </form>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php if($dataTypeContent->hasPages()): ?>
    <div class="row">
        <div class="col-md-12 text-right">
            <nav aria-label="Page navigation">
                <ul class="pagination">
                    <?php if($dataTypeContent->onFirstPage()): ?>
                    <li class="page-item disabled">
                        <span class="page-link">Previous</span>
                    </li>
                    <?php else: ?>
                    <li class="page-item">
                        <a class="page-link" href="<?php echo e($dataTypeContent->previousPageUrl()); ?>" aria-label="Previous">Previous</a>
                    </li>
                    <?php endif; ?>

                    <?php for($i = 1; $i <= $dataTypeContent->lastPage(); $i++): ?>
                        <li class="page-item <?php echo e($i === $dataTypeContent->currentPage() ? 'active' : ''); ?>">
                            <a class="page-link" href="<?php echo e($dataTypeContent->url($i)); ?>"><?php echo e($i); ?></a>
                        </li>
                        <?php endfor; ?>

                        <?php if($dataTypeContent->hasMorePages()): ?>
                        <li class="page-item">
                            <a class="page-link" href="<?php echo e($dataTypeContent->nextPageUrl()); ?>" aria-label="Next">Next</a>
                        </li>
                        <?php else: ?>
                        <li class="page-item disabled">
                            <span class="page-link">Next</span>
                        </li>
                        <?php endif; ?>
                </ul>
            </nav>
        </div>
    </div>
    <?php endif; ?>

    <div class="modal fade" id="offerModal" tabindex="-1" role="dialog" aria-labelledby="offerModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="offerModalLabel">Offer Details</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <p><strong>Offer Title:</strong> <span id="offerTitle"></span></p>
                    <p><strong>Offer Type:</strong> <span id="offerType"></span></p>
                    <p><strong>Discount:</strong> <span id="discount"></span></p>
                    <p><strong>Discounted Price:</strong><span id="discountedPrice"></span></p>
                </div>
            </div>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        const searchInput = document.getElementById('search');
        const itemsPerPage = document.getElementById('items-per-page');
        const productContainer = document.getElementById('product-list');

        searchInput.addEventListener('input', function() {
            // Check if the length of the search query meets the minimum requirement (e.g., 3 characters)
            if (searchInput.value.length >= 3) {
                fetchProducts();
            }
        });

        itemsPerPage.addEventListener('change', function() {
            fetchProducts();
        });

        function fetchProducts() {
            const searchQuery = searchInput.value;
            const perPage = itemsPerPage.value;
            fetch(`<?php echo e(route('voyager.products.index')); ?>?search=${searchQuery}&per_page=${perPage}`)
                .then(response => response.text())
                .then(html => {
                    const parser = new DOMParser();
                    const doc = parser.parseFromString(html, 'text/html');
                    const newContent = doc.getElementById('product-list').innerHTML;
                    productContainer.innerHTML = newContent;

                    const newPagination = doc.querySelector('.pagination');
                    const paginationContainer = document.querySelector('.pagination');
                    if (newPagination) {
                        paginationContainer.innerHTML = newPagination.innerHTML;
                    } else {
                        paginationContainer.innerHTML = '';
                    }
                })
                .catch(error => console.error('Error fetching products:', error));
        }

        const offerLink = document.querySelectorAll('[data-toggle="modal"][data-target="#offerModal"]');

        offerLink.forEach(function(link) {
            link.addEventListener('click', function(event) {
                event.preventDefault();
                const title = this.getAttribute('data-title');
                const price = parseFloat(this.getAttribute('data-price'));
                const type = this.getAttribute('data-type');
                const discount = this.getAttribute('data-discount');
                let discountedPrice = price;

                if (type === 'percentage') {
                    const discountPercentage = discount; // Change this to your actual percentage
                    discountedPrice = price - (price * (discountPercentage / 100));
                } else if (type === 'flat') {
                    const flatDiscount = discount; // Change this to your actual flat discount
                    discountedPrice = price - flatDiscount;
                }

                // Update modal content
                document.getElementById('offerTitle').innerText = title;
                document.getElementById('offerType').innerText = type.charAt(0).toUpperCase() + type.slice(1); // Capitalize first letter
                document.getElementById('discount').innerText = (type === 'percentage') ? Math.round(discount) + '%' : discount; // Capitalize first letter
                document.getElementById('discountedPrice').innerText = discountedPrice.toFixed(2); // Show price with 2 decimal places
            });
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('voyager::master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vikartr/Projects/mobile-admin-panel/resources/views/vendor/voyager/products/browse.blade.php ENDPATH**/ ?>