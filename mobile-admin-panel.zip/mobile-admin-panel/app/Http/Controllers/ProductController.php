<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Product;

class ProductController extends Controller
{
    public function index(Request $request)
    {
        $query = Product::query();

        if ($request->has('search') && $request->search != '') {
            $search = $request->search;
            $query->where('name', 'LIKE', "%{$search}%")
                ->orWhere('code', 'LIKE', "%{$search}%")
                ->orWhereHas('company', function ($query) use ($search) {
                    $query->where('name', 'LIKE', "%{$search}%");
                });
        }
        $totalProducts = $query->count();

        $perPage = $request->get('per_page', 10); // Default to 12 if not provided
        if ($perPage == 'all') {
            $dataTypeContent = $query->get();
        } else {
            $dataTypeContent = $query->paginate($perPage);
        }
    
        return view('voyager::products.browse', compact('dataTypeContent', 'totalProducts'));    }
}
